

function myFunction() {
let text;
  if (document.getElementById("id1").validity.rangeOverflow) {
     text = "Not available, check with the main distribuiton center";}
  else {
    text = "Quantity of the product is available";
  } 
  document.getElementById("demo").innerHTML = text;
}

